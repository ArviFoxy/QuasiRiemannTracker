/- Copyright (c) 2026 Hailey Collet. Released under Apache 2.0. -/
import Cycle61.Physical.InitialMass.GeometryChosenSetup
import Cycle61.Physical.InitialMass.GeometrySourceBudget

set_option autoImplicit false
namespace Cycle61.FinalAssembly
noncomputable section
open OAI.SevenEighths Cycle61InitialMass

/-- The actual chosen affine input follows from the original main and error
families and the fixed source geometry. -/
theorem chosen_affine_input : ChosenAffineInput :=
  chosen_affine_of_source_geometry actual_weighted_source_geometry_budget

/-- Cycle61's exact advertised supremum bound. -/
theorem beta_le_rational : HeckeZeroSupremum.beta≤(874861/1000000:ℝ) :=
  beta_le_rational_of_chosen_affine chosen_affine_input

end
end Cycle61.FinalAssembly
#print axioms Cycle61.FinalAssembly.chosen_affine_input
#print axioms Cycle61.FinalAssembly.beta_le_rational
